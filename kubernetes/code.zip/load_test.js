import http from "k6/http";
import { check, sleep } from "k6";

export const options = {
  scenarios: {
    ramp_up_load: {
      executor: "ramping-vus",
      startVUs: 1,
      stages: [
        { duration: "1m", target: 50 }, // warm up
        { duration: "2m", target: 150 }, // trigger HPA scale-up
        { duration: "2m", target: 300 }, // hold peak
        { duration: "1m", target: 0 }, // cool down
      ],
      gracefulRampDown: "30s",
    },
  },
  thresholds: {
    http_req_failed: ["rate<0.01"],
    http_req_duration: ["p(95)<4000"],
  },
};

const BASE_URL = __ENV.TARGET_URL || "http://127.0.0.1";
const REQUEST_PATH = __ENV.TARGET_PATH || "/joke";
const URL = `${BASE_URL}${REQUEST_PATH}`;

export default function () {
  const response = http.get(URL, {
    tags: {
      name: REQUEST_PATH,
    },
  });

  check(response, {
    "status is 200": (res) => res.status === 200,
  });

  sleep(1);
}
