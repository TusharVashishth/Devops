import express from "express";
import jokes from "./jokes.js";
const app = express();
const PORT = process.env.PORT || 8000;
const POD_NAME = process.env.HOSTNAME || "unknown"; // K8s sets this automatically

app.get("/health", (_req, res) => {
  res.status(200).json({ status: "ok" });
});

app.get("/", (req, res) => {
  res.json({ message: `Hello World from ${POD_NAME}`, status: 200 });
});

app.get("/joke", async (req, res) => {
  await new Promise((resolve) => setTimeout(resolve, 1500)); // simulate delay
  const random = jokes[Math.floor(Math.random() * jokes.length)];
  res.json({ joke: random, status: 200 });
});

app.listen(PORT, (err) => {
  if (err) {
    console.error("Error starting server:", err);
  } else {
    console.log(`Server is running on port ${PORT}`);
  }
});
