# Express Js With Typescript Starter KIT 🙌

## After cloning run the below command to run the project

```js
npm install && npm run dev
```

**Now All Set you can open below url to see your page**

```js 
http://localhost:8000
```
